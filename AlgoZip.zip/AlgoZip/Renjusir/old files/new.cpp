#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <regex>
#include <numeric>
#include <unordered_map>
#include <map>
#include <iomanip>
#include <ctime>
#include <cmath>
#include <filesystem>  // C++17 or higher

namespace fs = std::filesystem;

struct OrderBookLevel {
    int flag; // 1 = Buy, 0 = Sell
    int quantity;
    int price;
    int orders;
    int priceJump;
};

struct StockData {
    double last_price;
    double bestbuy;
    double bestsell;
    double volume;
    double ema_short;
    double ema_long;
    double rsi;
    double boll_upper;
    double boll_lower;
    std::string signal;
};

std::map<double, int> tokens = { {10604, 0}, {11532, 1}, {11630, 2}, {16669, 3}, {16675, 4}, {10999, 5}, {11536, 6},
    {1333, 7}, {15083, 8}, {157, 9}, {11483, 10}, {14977, 11}, {1660, 12}, {1348, 13},
    {11723, 14}, {21808, 15}, {1594, 16}, {3499, 17}, {1922, 18}, {2031, 19}, {1232, 20},
    {1394, 21}, {17963, 22}, {1964, 23}, {236, 24}, {20374, 25}, {25, 26}, {3787, 27},
    {4306, 28}, {4963, 29}, {526, 30}, {694, 31}, {881, 32}, {910, 33}, {1363, 34},
    {13538, 35}, {3351, 36}, {467, 37}, {2885, 38}, {317, 39}, {547, 40}, {2475, 41},
    {3045, 42}, {3432, 43}, {3506, 44}, {5900, 45}, {7229, 46}, {3456, 47}, {383, 48}, {5258, 49} };

double iStockData[50][1110][10] = {0};
int trck28500items[50] = {0};

double calculate_rsi(const std::vector<double>& prices, int period = 14) {
    if (prices.size() < period + 1) return 0.0;
    double gain = 0.0, loss = 0.0;
    for (size_t i = prices.size() - period; i < prices.size() - 1; ++i) {
        double diff = prices[i + 1] - prices[i];
        if (diff > 0) gain += diff;
        else loss -= diff;
    }
    if (loss == 0) return 100.0;
    double rs = gain / loss;
    return 100.0 - (100.0 / (1.0 + rs));
}

std::vector<OrderBookLevel> parse_orderbook_json(const std::string& raw_json, double paramLTP) {
    std::vector<OrderBookLevel> levels;
    std::regex entry_regex("\\{[^}]+\\}");
    std::regex field_regex("'([^']+)'\\s*:\\s*([0-9]+)");

    std::sregex_iterator entries_begin(raw_json.begin(), raw_json.end(), entry_regex);
    std::sregex_iterator entries_end;

    double iLTP = paramLTP;

    for (auto it = entries_begin; it != entries_end; ++it) {
        std::string entry = it->str();
        std::sregex_iterator field_it(entry.begin(), entry.end(), field_regex);
        OrderBookLevel level = {0, 0, 0, 0, 0};
        double priceJump = iLTP;

        for (; field_it != std::sregex_iterator(); ++field_it) {
            std::string key = (*field_it)[1];
            double value = std::stod((*field_it)[2]);

            if (key == "flag") level.flag = value;
            else if (key == "quantity") level.quantity = value;
            else if (key == "price") {
                level.price = value;
                priceJump -= value;
                level.priceJump = priceJump;
            }
            else if (key == "no of orders") level.orders = value;
        }
        levels.push_back(level);
    }
    return levels;
}

double compute_bid_ask_pressure_index(const std::vector<OrderBookLevel>& levels, bool is_bid) {
    int total_qty = 0;
    int weighted_price_sum = 0;

    for (const auto& level : levels) {
        if ((is_bid && level.flag == 1) || (!is_bid && level.flag == 0)) {
            total_qty += level.quantity;
            //weighted_price_sum += level.quantity * level.priceJump;
            weighted_price_sum += level.priceJump;
        }
    }
    return (total_qty > 0) ? static_cast<double>(weighted_price_sum) / total_qty : 0.0;
}


double calculate_sma(const std::vector<double>& prices, int period) {
    if (prices.size() < period) return 0.0;
    return std::accumulate(prices.end() - period, prices.end(), 0.0) / period;
}

double calculate_stddev(const std::vector<double>& prices, double mean, int period) {
    if (prices.size() < period) return 0.0;
    double sum = 0.0;
    for (size_t i = prices.size() - period; i < prices.size(); ++i) {
        sum += std::pow(prices[i] - mean, 2);
    }
    return std::sqrt(sum / period);
}

void display_all_stock_data() {
    for (int i = 0; i < 50; i++) {
        std::cout << "Stock Index: " << i << "\n";
        for (int j = 0; j < trck28500items[i]; j++) {
            std::cout << "Last Price: " << iStockData[i][j][0] << ", "
                      << "Best Buy: " << iStockData[i][j][1] << ", "
                      << "Best Sell: " << iStockData[i][j][2] << ", "
                      << "Volume: " << iStockData[i][j][3] << ", "
                      << "EMA Short: " << iStockData[i][j][4] << ", "
                      << "EMA Long: " << iStockData[i][j][5] << ", "
                      << "RSI: " << iStockData[i][j][6] << ", "
                      << "Boll Upper: " << iStockData[i][j][7] << ", "
                      << "Boll Lower: " << iStockData[i][j][8] << ", "
                      << "Signal: " << iStockData[i][j][9] << "\n";
        }
    }
}

void update_stock_array(double symbol, double last_price, double bestbuy, double bestsell,
    double volume, double ema_short, double ema_long, double rsi, double boll_upper, double boll_lower, double signal) {

    if (tokens.find(symbol) == tokens.end()) return;
    int symbol_index = tokens[symbol];

    int iTrackStockIndex = trck28500items[symbol_index];

    iStockData[symbol_index][iTrackStockIndex][0] = last_price;
    iStockData[symbol_index][iTrackStockIndex][1] = bestbuy;
    iStockData[symbol_index][iTrackStockIndex][2] = bestsell;
    iStockData[symbol_index][iTrackStockIndex][3] = volume;
    iStockData[symbol_index][iTrackStockIndex][4] = ema_short;
    iStockData[symbol_index][iTrackStockIndex][5] = ema_long;
    iStockData[symbol_index][iTrackStockIndex][6] = rsi;
    iStockData[symbol_index][iTrackStockIndex][7] = boll_upper;
    iStockData[symbol_index][iTrackStockIndex][8] = boll_lower;
    iStockData[symbol_index][iTrackStockIndex][9] = signal;

    trck28500items[symbol_index]++;
    if (trck28500items[symbol_index] >= 1110) {
        std::cerr << "[WARNING] Stock data for symbol " << symbol << " is full, resetting index.\n";
        trck28500items[symbol_index] = 0;
    }
}

std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> result;
    std::string current_field;
    bool inside_quotes = false;

    for (char ch : line) {
        if (ch == '"') inside_quotes = !inside_quotes;
        if (ch == ',' && !inside_quotes) {
            result.push_back(current_field);
            current_field.clear();
        } else {
            current_field += ch;
        }
    }
    if (!current_field.empty()) result.push_back(current_field);
    return result;
}

void calculate_indicators_and_update(double symbol, double last_price, const std::string& best_5_buy_json, const std::string& best_5_sell_json, double volume) {
    if (tokens.find(symbol) == tokens.end()) return;
    int idx = tokens[symbol];
    int count = trck28500items[idx];

    std::vector<double> prices;
    for (int i = 0; i < count; ++i) prices.push_back(iStockData[idx][i][0]);
    prices.push_back(last_price);

    double sma = calculate_sma(prices, 20);
    double stddev = calculate_stddev(prices, sma, 20);
    double upper_band = sma + 2 * stddev;
    double lower_band = sma - 2 * stddev;
    double rsi = calculate_rsi(prices);

    auto buy_levels = parse_orderbook_json(best_5_buy_json, last_price);
    auto sell_levels = parse_orderbook_json(best_5_sell_json, last_price);

    float bid_index = compute_bid_ask_pressure_index(buy_levels, true);
    float ask_index = compute_bid_ask_pressure_index(sell_levels, false);


    double signal = 0.0;
    update_stock_array(symbol, last_price, ask_index, bid_index, volume, 0.0, 0.0, rsi, upper_band, lower_band, signal);
}

double extract_time_as_int(const std::string& timestamp) {
    // Expected format: "YYYY-MM-DD HH:MM:SS"
    size_t space_pos = timestamp.find(' ');
    if (space_pos == std::string::npos || space_pos + 1 >= timestamp.size())
        return -1; // Invalid format

    std::string time_part = timestamp.substr(space_pos + 1); // HH:MM:SS
    std::string time_compact;

    for (char ch : time_part) {
        if (ch != ':') {
            time_compact += ch;
        }
    }

    try {
        return std::stod(time_compact); // e.g., "093505" → 93505
    } catch (...) {
        return -1;
    }
}

std::string get_current_timestamp() {
    std::time_t now = std::time(nullptr);         // Get current time
    std::tm* local_tm = std::localtime(&now);     // Convert to local time struct

    std::ostringstream oss;
    oss << std::put_time(local_tm, "%Y-%m-%d %H:%M:%S");  // Format
    return oss.str();
}

int timestamp_diff_seconds(const std::string& ts1, const std::string& ts2) {
    std::tm tm1 = {}, tm2 = {};
    std::istringstream ss1(ts1);
    std::istringstream ss2(ts2);

    ss1 >> std::get_time(&tm1, "%Y-%m-%d %H:%M:%S");
    ss2 >> std::get_time(&tm2, "%Y-%m-%d %H:%M:%S");

    if (ss1.fail() || ss2.fail()) {
        std::cerr << "Invalid timestamp format.\n";
        return 0;
    }

    std::time_t time1 = std::mktime(&tm1);
    std::time_t time2 = std::mktime(&tm2);

    return static_cast<int>(std::difftime(time1, time2));
}
void write_stock_data_to_csv(const std::string& filename) {
    std::ofstream out_file(filename);
    if (!out_file.is_open()) {
        std::cerr << "[ERROR] Failed to open output file: " << filename << "\n";
        return;
    }

    // Write header
    out_file << "SymbolIndex,LastPrice,BestBuy,BestSell,Volume,EMA_Short,EMA_Long,RSI,Boll_Upper,Boll_Lower,Signal\n";

    for (int i = 0; i < 50; ++i) {
        for (int j = 0; j < trck28500items[i]; ++j) {
            out_file << i << ","  // Symbol index
                     << iStockData[i][j][0] << ","  // Last Price
                     << iStockData[i][j][1] << ","  // Best Buy
                     << iStockData[i][j][2] << ","  // Best Sell
                     << iStockData[i][j][3] << ","  // Volume
                     << iStockData[i][j][4] << ","  // EMA Short
                     << iStockData[i][j][5] << ","  // EMA Long
                     << iStockData[i][j][6] << ","  // RSI
                     << iStockData[i][j][7] << ","  // Boll Upper
                     << iStockData[i][j][8] << ","  // Boll Lower
                     << iStockData[i][j][9]         // Signal
                     << "\n";
        }
    }

    out_file.close();
    std::cout << "[INFO] Output written to CSV file: " << filename << "\n";
}



int main() {
    std::string folder_path = "/mnt/c/Streaming_data/_1_minute_data/2025-05-02";
    std::vector<fs::path> txt_files;

    // Step 1: Collect all .txt files in the folder
    for (const auto& entry : fs::directory_iterator(folder_path)) {
        if (entry.path().extension() == ".csv") {
            txt_files.push_back(entry.path());
        }
    }

    if (txt_files.empty()) {
        std::cerr << "[ERROR] No .txt files found in directory: " << folder_path << std::endl;
        return 1;
    }

    std::string startingTS = get_current_timestamp();
    double iExtractTime = 0.0;
    int total_line_count = 0;

    // Step 2: Process each .txt file
    for (const auto& filepath : txt_files) {
        std::ifstream file(filepath);
        if (!file.is_open()) {
            std::cerr << "[ERROR] Failed to open file: " << filepath << std::endl;
            continue;
        }

        std::cout << "[INFO] Processing file: " << filepath << "\n";

        std::string line;
        std::getline(file, line); // Skip header

        while (std::getline(file, line)) {
            if (line.empty()) continue;
            total_line_count++;

            auto columns = split_csv_line(line);
            if (columns.size() <= 24) continue;

            double symbol = std::stod(columns[2]);
            iExtractTime = extract_time_as_int(columns[4]);
            double last_price = std::stod(columns[5]);
            std::string best_5_buy_data = columns[23];
            std::string best_5_sell_data = columns[24];

            calculate_indicators_and_update(symbol, last_price, best_5_buy_data, best_5_sell_data, 0.0);
        }

        file.close();
    }

    // Step 3: Show results and time metrics
    display_all_stock_data();

    write_stock_data_to_csv("output.csv");
    
    std::string endingTS = get_current_timestamp();
    int diff = timestamp_diff_seconds(endingTS, startingTS);

    std::cout << "[INFO] Time difference: " << diff << " seconds\n";
    std::cout << "[INFO] Extracted data for " << tokens.size() << " stocks.\n";
    std::cout << "[INFO] Last extracted timestamp: " << iExtractTime << "\n";
    std::cout << "[INFO] Total lines processed: " << total_line_count << "\n";
    std::cout << "[INFO] Done processing all files and calculating indicators.\n";

    return 0;
}
