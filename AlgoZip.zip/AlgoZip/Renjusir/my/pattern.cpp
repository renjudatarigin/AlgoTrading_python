// optimized code -run in 2 seconds 
// CPP CODE WHICH EXTRACTS SymbolIndex,LastPrice,BestBuy,BestSell,Volume 
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <iomanip>
#include <ctime>
#include <filesystem>

namespace fs = std::filesystem;

struct OrderBookLevel {
    int flag; // 1 = Buy, 0 = Sell
    int quantity;
    int price;
    int orders;
    int priceJump;
};

std::map<double, int> tokens = {
    {10604, 0}, {11532, 1}, {11630, 2}, {16669, 3}, {16675, 4}, {10999, 5},
    {11536, 6}, {1333, 7}, {15083, 8}, {157, 9}, {11483, 10}, {14977, 11},
    {1660, 12}, {1348, 13}, {11723, 14}, {21808, 15}, {1594, 16}, {3499, 17},
    {1922, 18}, {2031, 19}, {1232, 20}, {1394, 21}, {17963, 22}, {1964, 23},
    {236, 24}, {20374, 25}, {25, 26}, {3787, 27}, {4306, 28}, {4963, 29},
    {526, 30}, {694, 31}, {881, 32}, {910, 33}, {1363, 34}, {13538, 35},
    {3351, 36}, {467, 37}, {2885, 38}, {317, 39}, {547, 40}, {2475, 41},
    {3045, 42}, {3432, 43}, {3506, 44}, {5900, 45}, {7229, 46}, {3456, 47},
    {383, 48}, {5258, 49}
};

double iStockData[50][1110][4] = {0};
int trck28500items[50] = {0};

std::vector<OrderBookLevel> parse_orderbook_json(const std::string& raw_json, double ltp) {
    std::vector<OrderBookLevel> levels;
    levels.reserve(5); // we expect only 5 levels

    size_t pos = 0;
    while ((pos = raw_json.find('{', pos)) != std::string::npos) {
        size_t end = raw_json.find('}', pos);
        if (end == std::string::npos) break;

        std::string entry = raw_json.substr(pos + 1, end - pos - 1);
        OrderBookLevel level = {0, 0, 0, 0, 0};

        std::stringstream ss(entry);
        std::string kv;
        while (std::getline(ss, kv, ',')) {
            size_t key_start = kv.find('\'');
            size_t key_end = kv.find('\'', key_start + 1);
            if (key_start == std::string::npos || key_end == std::string::npos) continue;

            std::string key = kv.substr(key_start + 1, key_end - key_start - 1);
            std::string val_str = kv.substr(kv.find(':') + 1);
            int value = std::stoi(val_str);

            if (key == "flag") level.flag = value;
            else if (key == "quantity") level.quantity = value;
            else if (key == "price") {
                level.price = value;
                level.priceJump = static_cast<int>(ltp) - value;
            }
            else if (key == "no of orders") level.orders = value;
        }

        levels.push_back(level);
        pos = end + 1;
    }

    return levels;
}

double compute_bid_ask_pressure_index(const std::vector<OrderBookLevel>& levels, bool is_bid) {
    int total_qty = 0;
    int weighted_price_sum = 0;

    for (const auto& level : levels) {
        if ((is_bid && level.flag == 1) || (!is_bid && level.flag == 0)) {
            total_qty += level.quantity;
            weighted_price_sum += level.priceJump;
        }
    }
    return (total_qty > 0) ? static_cast<double>(weighted_price_sum) / total_qty : 0.0;
}

void update_stock_array(double symbol, double last_price, double ask_index, double bid_index, double volume) {
    auto it = tokens.find(symbol);
    if (it == tokens.end()) return;

    int idx = it->second;
    int track = trck28500items[idx];

    iStockData[idx][track][0] = last_price;
    iStockData[idx][track][1] = ask_index;
    iStockData[idx][track][2] = bid_index;
    iStockData[idx][track][3] = volume;

    trck28500items[idx]++;
    if (trck28500items[idx] >= 1110) {
        std::cerr << "[WARNING] Data overflow for symbol " << symbol << ", resetting index.\n";
        trck28500items[idx] = 0;
    }
}

void display_all_stock_data() {
    for (int i = 0; i < 50; ++i) {
        std::cout << "Stock Index: " << i << "\n";
        for (int j = 0; j < trck28500items[i]; ++j) {
            std::cout << "Last Price: " << iStockData[i][j][0]
                      << ", Ask Index: " << iStockData[i][j][1]
                      << ", Bid Index: " << iStockData[i][j][2]
                      << ", Volume: " << iStockData[i][j][3] << "\n";
        }
    }
}

std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> result;
    result.reserve(30);
    std::string field;
    bool inside_quotes = false;

    for (char ch : line) {
        if (ch == '"') {
            inside_quotes = !inside_quotes;
        } else if (ch == ',' && !inside_quotes) {
            result.push_back(std::move(field));
            field.clear();
        } else {
            field += ch;
        }
    }
    if (!field.empty()) result.push_back(std::move(field));
    return result;
}
double extract_time_as_int(const std::string& timestamp) {
    // Expected format: "YYYY-MM-DD HH:MM:SS"
    size_t space_pos = timestamp.find(' ');
    if (space_pos == std::string::npos || space_pos + 1 >= timestamp.size())
        return -1; // Invalid format

    std::string time_part = timestamp.substr(space_pos + 1); // HH:MM:SS
    std::string time_compact;

    for (char ch : time_part) {
        if (ch != ':') {
            time_compact += ch;
        }
    }

    try {
        return std::stod(time_compact); // e.g., "093505" → 93505
    } catch (...) {
        return -1;
    }
}

std::string get_current_timestamp() {
    std::time_t now = std::time(nullptr);         // Get current time
    std::tm* local_tm = std::localtime(&now);     // Convert to local time struct

    std::ostringstream oss;
    oss << std::put_time(local_tm, "%Y-%m-%d %H:%M:%S");  // Format
    return oss.str();
}

int timestamp_diff_seconds(const std::string& ts1, const std::string& ts2) {
    std::tm tm1 = {}, tm2 = {};
    std::istringstream ss1(ts1);
    std::istringstream ss2(ts2);

    ss1 >> std::get_time(&tm1, "%Y-%m-%d %H:%M:%S");
    ss2 >> std::get_time(&tm2, "%Y-%m-%d %H:%M:%S");

    if (ss1.fail() || ss2.fail()) {
        std::cerr << "Invalid timestamp format.\n";
        return 0;
    }

    std::time_t time1 = std::mktime(&tm1);
    std::time_t time2 = std::mktime(&tm2);

    return static_cast<int>(std::difftime(time1, time2));
}

void write_stock_data_to_csv(const std::string& filename) {
    std::ofstream out_file(filename);
    if (!out_file.is_open()) {
        std::cerr << "[ERROR] Failed to open output file: " << filename << "\n";
        return;
    }

    out_file << "SymbolIndex,LastPrice,BestBuy,BestSell,Volume\n";
    for (int i = 0; i < 50; ++i) {
        for (int j = 0; j < trck28500items[i]; ++j) {
            out_file << j << ","
                     << iStockData[i][j][0] << ","
                     << iStockData[i][j][1] << ","
                     << iStockData[i][j][2] << ","
                     << iStockData[i][j][3] << "\n";
        }
    }

    out_file.close();
    std::cout << "[INFO] Output written to CSV file: " << filename << "\n";
}

int main() {
    std::string folder_path = "/mnt/c/Streaming_data/_1_minute_data/2025-05-05";
    std::vector<fs::path> csv_files;
    double iExtractTime = 0.0;
    int total_line_count = 0;
    std::string startingTS = get_current_timestamp();

    for (const auto& entry : fs::directory_iterator(folder_path)) {
        if (entry.path().extension() == ".csv") {
            csv_files.push_back(entry.path());
        }
    }

    if (csv_files.empty()) {
        std::cerr << "[ERROR] No .csv files found in directory: " << folder_path << "\n";
        return 1;
    }

    for (const auto& filepath : csv_files) {
        std::ifstream file(filepath);
        if (!file.is_open()) {
            std::cerr << "[ERROR] Failed to open: " << filepath << "\n";
            continue;
        }
        std::cout << "[INFO] Processing file: " << filepath << "\n";

        std::string line;
        std::getline(file, line); // Skip header

        while (std::getline(file, line)) {
            if (line.empty()) continue;
            int total_line_count = 0;

            auto columns = split_csv_line(line);
            if (columns.size() <= 24) continue;

            double symbol = std::stod(columns[2]);
            double last_price = std::stod(columns[5]);
            double volume = std::stod(columns[9]);
            iExtractTime = extract_time_as_int(columns[4]);
            const std::string& best_5_buy_data = columns[23];
            const std::string& best_5_sell_data = columns[24];

            auto buy_levels = parse_orderbook_json(best_5_buy_data, last_price);
            auto sell_levels = parse_orderbook_json(best_5_sell_data, last_price);

            double bid_index = compute_bid_ask_pressure_index(buy_levels, true);
            double ask_index = compute_bid_ask_pressure_index(sell_levels, false);

            update_stock_array(symbol, last_price, ask_index, bid_index, volume);
        }

        file.close();
    }
        // Step 3: Show results and time metrics
    display_all_stock_data();

    write_stock_data_to_csv("output01july_optimized.csv");

    std::string endingTS = get_current_timestamp();
    int diff = timestamp_diff_seconds(endingTS, startingTS);

    std::cout << "[INFO] Time difference: " << diff << " seconds\n";
    std::cout << "[INFO] Extracted data for " << tokens.size() << " stocks.\n";
    std::cout << "[INFO] Last extracted timestamp: " << iExtractTime << "\n";
    std::cout << "[INFO] Total lines processed: " << total_line_count << "\n";
    std::cout << "[INFO] Done processing all files and calculating indicators.\n";

    std::cout << "[INFO] Completed processing.\n";
    return 0;
}
