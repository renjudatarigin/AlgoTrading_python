// Reads multiple CSV files from a folder (each file is 1-minute market data).
// Consolidates the data per token per minute (open, high, low, close, volume).
// Stores the consolidated candles in an in-memory std::unordered_map<int, std::vector<TokenData>>.
// Writes the consolidated output to consolidated_output.csv.
// need to implement the occurence of hammer- hammer implimenation is done in the hammer.cpp

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <filesystem>
#include <limits>
#include <algorithm>

namespace fs = std::filesystem;

struct TokenData {
    std::string timestamp;
    int open_price = -1;
    int high_price = std::numeric_limits<int>::min();
    int low_price = std::numeric_limits<int>::max();
    int close_price = -1;
    int volume = 0;
};

// token → vector of TokenData sorted by time
std::unordered_map<int, std::vector<TokenData>> tokenCandles;

int main() {
    std::string folderPath = "/mnt/c/Streaming_data/_1_minute_data/2025-05-02";

    std::map<int, std::vector<std::vector<std::string>>> groupedData;
    std::unordered_map<std::string, int> headerIndex;
    bool headerParsed = false;

    for (const auto& entry : fs::directory_iterator(folderPath)) {
        if (!entry.is_regular_file()) continue;

        std::ifstream file(entry.path());
        if (!file.is_open()) {
            std::cerr << "Error opening file: " << entry.path() << "\n";
            continue;
        }

        std::string line;
        std::getline(file, line); // Read header

        if (!headerParsed) {
            std::istringstream headerStream(line);
            std::string col;
            int idx = 0;
            while (std::getline(headerStream, col, ',')) {
                headerIndex[col] = idx++;
            }

            std::vector<std::string> required = {
                "token", "exchange_timestamp", "last_traded_price", "volume_trade_for_the_day"
            };
            for (const auto& col : required) {
                if (headerIndex.find(col) == headerIndex.end()) {
                    std::cerr << "Missing required column: " << col << "\n";
                    return 1;
                }
            }

            headerParsed = true;
        }

        // Process lines
        while (std::getline(file, line)) {
            std::vector<std::string> row;
            std::istringstream ss(line);
            std::string value;
            while (std::getline(ss, value, ',')) {
                row.push_back(value);
            }

            if (row.size() < headerIndex.size()) continue;

            int token = std::stoi(row[headerIndex["token"]]);
            groupedData[token].push_back(row);
        }

        file.close();
    }

    // Write consolidated CSV
    std::ofstream output("cond_folder.csv");
    if (!output.is_open()) {
        std::cerr << "Error: Cannot create output file.\n";
        return 1;
    }
    output << "token,timestamp,open,high,low,close,volume\n";

    for (const auto& [token, rows] : groupedData) {
        std::map<std::string, std::vector<std::vector<std::string>>> minuteGroups;

        for (const auto& row : rows) {
            std::string timestamp = row[headerIndex["exchange_timestamp"]];
            std::string minute = timestamp.substr(0, 16); // e.g., 2025-05-02 09:15
            minuteGroups[minute].push_back(row);
        }

        for (const auto& [minute, rowsInMinute] : minuteGroups) {
            TokenData data;
            data.timestamp = minute + ":00";

            for (size_t i = 0; i < rowsInMinute.size(); ++i) {
                const auto& row = rowsInMinute[i];
                int price = std::stoi(row[headerIndex["last_traded_price"]]);
                int vol = std::stoi(row[headerIndex["volume_trade_for_the_day"]]);

                if (i == 0) data.open_price = price;
                data.high_price = std::max(data.high_price, price);
                data.low_price = std::min(data.low_price, price);
                data.close_price = price;
                data.volume = vol;
            }

            // Store in memory for future analysis
            tokenCandles[token].push_back(data);

            // Write to CSV
            output << token << ","
                   << data.timestamp << ","
                   << data.open_price << ","
                   << data.high_price << ","
                   << data.low_price << ","
                   << data.close_price << ","
                   << data.volume << "\n";
        }
    }

    output.close();
    std::cout << "Consolidated data written to 'consolidated_output.csv'\n";

    // ✅ You can now perform pattern analysis on tokenCandles map
    return 0;
}
