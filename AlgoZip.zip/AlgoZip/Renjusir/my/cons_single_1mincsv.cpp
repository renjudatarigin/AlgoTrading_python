// reading data form single csv file 
// this file only takes single csv file and grouping only using token , not per token per minute 
// ONLY USES FOR SINGLE ONE MINUTE CSV FILE 
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <limits>
#include <algorithm>

struct TokenData {
    std::string timestamp;
    int open_price = -1;
    int high_price = std::numeric_limits<int>::min();
    int low_price = std::numeric_limits<int>::max();
    int close_price = -1;
    int volume = 0;
};

int main() {
    std::ifstream file("/mnt/c/Streaming_data/_1_minute_data/2025-05-02/20250502_0915.csv");
    if (!file.is_open()) {
        std::cerr << "Error: Cannot open input file. Check path and permissions.\n";
        return 1;
    }

    std::ofstream output("test.csv");  // Output CSV file
    if (!output.is_open()) {
        std::cerr << "Error: Cannot create output file.\n";
        return 1;
    }

    std::string line;
    std::getline(file, line); // Skip header

    std::unordered_map<int, std::vector<std::vector<std::string>>> tokenGroups;
    std::unordered_map<std::string, int> headerIndex;

    // Parse header
    std::istringstream headerStream(line);
    std::string col;
    int idx = 0;
    while (std::getline(headerStream, col, ',')) {
        headerIndex[col] = idx++;
    }

    std::vector<std::string> required = {
        "token", "exchange_timestamp", "last_traded_price", "volume_trade_for_the_day"
    };
    for (const auto& col : required) {
        if (headerIndex.find(col) == headerIndex.end()) {
            std::cerr << "Missing required column: " << col << "\n";
            return 1;
        }
    }

    // Read and group data
    while (std::getline(file, line)) {
        std::vector<std::string> row;
        std::istringstream ss(line);
        std::string value;
        while (std::getline(ss, value, ',')) {
            row.push_back(value);
        }

        if (row.size() < idx) continue;

        int token = std::stoi(row[headerIndex["token"]]);
        tokenGroups[token].push_back(row);
    }

    file.close();

    // Write CSV header
    output << "token,timestamp,open,high,low,close,volume\n";

    // Process each token group
    for (const auto& [token, rows] : tokenGroups) {
        if (rows.empty()) continue;

        TokenData data;

        for (size_t i = 0; i < rows.size(); ++i) {
            const auto& row = rows[i];
            int price = std::stoi(row[headerIndex["last_traded_price"]]);
            int volume = std::stoi(row[headerIndex["volume_trade_for_the_day"]]);
            const std::string& timestamp = row[headerIndex["exchange_timestamp"]];

            if (i == 0) {
                data.timestamp = timestamp;
                data.open_price = price;
            }
            data.high_price = std::max(data.high_price, price);
            data.low_price = std::min(data.low_price, price);
            data.close_price = price;
            data.volume = volume; // Take last volume
        }

        // Write to output CSV
        output << token << ","
               << data.timestamp << ","
               << data.open_price << ","
               << data.high_price << ","
               << data.low_price << ","
               << data.close_price << ","
               << data.volume << "\n";
    }

    output.close();
    std::cout << "Summary written to 'summary_output.csv'\n";
    return 0;
}
