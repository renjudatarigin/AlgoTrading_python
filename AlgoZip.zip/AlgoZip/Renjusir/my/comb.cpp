// swing_high	1 if this candle is a local high point (i.e., high > prev and next high), else 0.
// swing_low	1 if this candle is a local low point, else 0.
// zigzag_peak	1 if it shows significant reversal based on price change threshold (e.g., 1.5%), else 0.
// sma_20	20-period Simple Moving Average of close prices (starts appearing from row 20).
// rsi_14	14-period Relative Strength Index (momentum indicator, from row 14).
// volume_spike	1 if volume increased by >50% compared to previous candle, else 0.

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <filesystem>
#include <limits>
#include <algorithm>
#include <cmath>
#include <numeric>

namespace fs = std::filesystem;

struct TokenData {
    std::string timestamp;
    int open_price = -1;
    int high_price = std::numeric_limits<int>::min();
    int low_price = std::numeric_limits<int>::max();
    int close_price = -1;
    int volume = 0;
};

std::unordered_map<int, std::vector<TokenData>> tokenCandles;

std::string detectPattern(const TokenData& candle) {
    int body = std::abs(candle.close_price - candle.open_price);
    int upper_shadow = candle.high_price - std::max(candle.close_price, candle.open_price);
    int lower_shadow = std::min(candle.close_price, candle.open_price) - candle.low_price;

    if (body == 0) return "none";
    if (lower_shadow >= 2 * body && upper_shadow <= body / 2) return "hammer";
    if (upper_shadow >= 2 * body && lower_shadow <= body / 2) return "shooting_star";
    return "none";
}

std::vector<TokenData> aggregateCandles(const std::vector<TokenData>& candles, int n) {
    std::vector<TokenData> result;
    for (size_t i = 0; i + n <= candles.size(); i++) {
        TokenData agg;
        agg.timestamp = candles[i].timestamp;
        agg.open_price = candles[i].open_price;
        agg.high_price = std::numeric_limits<int>::min();
        agg.low_price = std::numeric_limits<int>::max();
        agg.volume = 0;

        for (int j = 0; j < n; ++j) {
            const auto& c = candles[i + j];
            agg.high_price = std::max(agg.high_price, c.high_price);
            agg.low_price = std::min(agg.low_price, c.low_price);
            agg.close_price = c.close_price;
            agg.volume += c.volume;
        }
        result.push_back(agg);
    }
    return result;
}

bool isSwingHigh(const std::vector<TokenData>& candles, int i) {
    if (i == 0 || i >= candles.size() - 1) return false;
    return candles[i].high_price > candles[i - 1].high_price &&
           candles[i].high_price > candles[i + 1].high_price;
}

bool isSwingLow(const std::vector<TokenData>& candles, int i) {
    if (i == 0 || i >= candles.size() - 1) return false;
    return candles[i].low_price < candles[i - 1].low_price &&
           candles[i].low_price < candles[i + 1].low_price;
}

double computeSMA(const std::vector<TokenData>& candles, int i, int period) {
    if (i + 1 < period) return -1;
    double sum = 0;
    for (int j = i - period + 1; j <= i; ++j) {
        sum += candles[j].close_price;
    }
    return sum / period;
}

double computeRSI(const std::vector<TokenData>& candles, int i, int period = 14) {
    if (i < period) return -1;
    double gain = 0, loss = 0;
    for (int j = i - period + 1; j <= i; ++j) {
        int diff = candles[j].close_price - candles[j - 1].close_price;
        if (diff > 0) gain += diff;
        else loss -= diff;
    }
    if (loss == 0) return 100.0;
    double rs = gain / loss;
    return 100.0 - (100.0 / (1 + rs));
}

bool isZigzagTurningPoint(const std::vector<TokenData>& candles, int i, double thresholdPercent = 1.5) {
    if (i < 2 || i >= candles.size() - 2) return false;
    double diff1 = std::abs(candles[i].close_price - candles[i - 1].close_price);
    double diff2 = std::abs(candles[i + 1].close_price - candles[i].close_price);
    double base = candles[i - 1].close_price;
    return (diff1 / base * 100 > thresholdPercent && diff2 / base * 100 > thresholdPercent);
}

int main() {
    std::string folderPath = "/mnt/c/Streaming_data/_1_minute_data/2025-05-02";
    std::map<int, std::vector<std::vector<std::string>>> groupedData;
    std::unordered_map<std::string, int> headerIndex;
    bool headerParsed = false;

    for (const auto& entry : fs::directory_iterator(folderPath)) {
        if (!entry.is_regular_file()) continue;
        std::ifstream file(entry.path());
        if (!file.is_open()) continue;

        std::string line;
        std::getline(file, line);
        if (!headerParsed) {
            std::istringstream ss(line);
            std::string col;
            int idx = 0;
            while (std::getline(ss, col, ',')) headerIndex[col] = idx++;
            headerParsed = true;
        }

        while (std::getline(file, line)) {
            std::istringstream ss(line);
            std::vector<std::string> row;
            std::string value;
            while (std::getline(ss, value, ',')) row.push_back(value);
            if (row.size() < headerIndex.size()) continue;
            int token = std::stoi(row[headerIndex["token"]]);
            groupedData[token].push_back(row);
        }
    }

    std::ofstream output("peaks_patterns.csv");
    output << "token,timestamp,open,high,low,close,volume,pattern_1m,pattern_3m,pattern_5m,"
           << "swing_high,swing_low,zigzag_peak,sma_20,rsi_14,volume_spike\n";

    for (const auto& [token, rows] : groupedData) {
        std::map<std::string, std::vector<std::vector<std::string>>> minuteGroups;
        for (const auto& row : rows) {
            std::string ts = row[headerIndex["exchange_timestamp"]];
            std::string minute = ts.substr(0, 16);
            minuteGroups[minute].push_back(row);
        }

        std::vector<TokenData> candles;
        for (const auto& [minute, rowsInMinute] : minuteGroups) {
            TokenData data;
            data.timestamp = minute + ":00";
            for (size_t i = 0; i < rowsInMinute.size(); ++i) {
                const auto& row = rowsInMinute[i];
                int price = std::stoi(row[headerIndex["last_traded_price"]]);
                int vol = std::stoi(row[headerIndex["volume_trade_for_the_day"]]);
                if (i == 0) data.open_price = price;
                data.high_price = std::max(data.high_price, price);
                data.low_price = std::min(data.low_price, price);
                data.close_price = price;
                data.volume = vol;
            }
            candles.push_back(data);
        }

        tokenCandles[token] = candles;
        auto candles3m = aggregateCandles(candles, 3);
        auto candles5m = aggregateCandles(candles, 5);

        for (size_t i = 0; i < candles.size(); ++i) {
            std::string p1 = detectPattern(candles[i]);
            std::string p3 = (i + 3 <= candles.size()) ? detectPattern(candles3m[i]) : "na";
            std::string p5 = (i + 5 <= candles.size()) ? detectPattern(candles5m[i]) : "na";

            bool swingHigh = isSwingHigh(candles, i);
            bool swingLow = isSwingLow(candles, i);
            bool zigzag = isZigzagTurningPoint(candles, i);
            double sma20 = computeSMA(candles, i, 20);
            double rsi14 = computeRSI(candles, i, 14);
            bool volumeSpike = (i > 0 && candles[i].volume > 1.5 * candles[i - 1].volume);

            output << token << "," << candles[i].timestamp << "," << candles[i].open_price << ","
                   << candles[i].high_price << "," << candles[i].low_price << ","
                   << candles[i].close_price << "," << candles[i].volume << ","
                   << p1 << "," << p3 << "," << p5 << ","
                   << swingHigh << "," << swingLow << "," << zigzag << ","
                   << (sma20 >= 0 ? std::to_string(sma20) : "na") << ","
                   << (rsi14 >= 0 ? std::to_string(rsi14) : "na") << ","
                   << volumeSpike << "\n";
        }
    }

    std::cout << "Complete. Check 'peaks_patterns.csv' for results.\n";
    return 0;
}
