#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <filesystem>
#include <limits>
#include <algorithm>
#include <cmath>
#include <thread>
#include <mutex>

namespace fs = std::filesystem;

struct TokenData {
    std::string timestamp;
    int open_price = -1;
    int high_price = std::numeric_limits<int>::min();
    int low_price = std::numeric_limits<int>::max();
    int close_price = -1;
    int volume = 0;
};

std::string detectPattern(const TokenData& candle) {
    int body = std::abs(candle.close_price - candle.open_price);
    int upper_shadow = candle.high_price - std::max(candle.close_price, candle.open_price);
    int lower_shadow = std::min(candle.close_price, candle.open_price) - candle.low_price;

    if (body == 0) return "none";

    if (lower_shadow >= 2 * body && upper_shadow <= body / 2) return "hammer";
    if (upper_shadow >= 2 * body && lower_shadow <= body / 2) return "shooting_star";

    return "none";
}

std::vector<TokenData> aggregateCandles(const std::vector<TokenData>& candles, int n) {
    std::vector<TokenData> result;

    for (size_t i = 0; i + n <= candles.size(); i++) {
        TokenData agg;
        agg.timestamp = candles[i].timestamp;
        agg.open_price = candles[i].open_price;
        agg.high_price = std::numeric_limits<int>::min();
        agg.low_price = std::numeric_limits<int>::max();
        agg.volume = 0;

        for (int j = 0; j < n; ++j) {
            const auto& c = candles[i + j];
            agg.high_price = std::max(agg.high_price, c.high_price);
            agg.low_price = std::min(agg.low_price, c.low_price);
            agg.close_price = c.close_price;
            agg.volume += c.volume;
        }

        result.push_back(agg);
    }

    return result;
}

void processToken(
    int token,
    const std::vector<std::vector<std::string>>& rows,
    const std::unordered_map<std::string, int>& headerIndex,
    std::mutex& outputMutex,
    std::ofstream& output)
{
    std::map<std::string, std::vector<std::vector<std::string>>> minuteGroups;

    for (const auto& row : rows) {
        std::string timestamp = row[headerIndex.at("exchange_timestamp")];
        std::string minute = timestamp.substr(0, 16);
        minuteGroups[minute].push_back(row);
    }

    std::vector<TokenData> candles;
    for (const auto& [minute, rowsInMinute] : minuteGroups) {
        TokenData data;
        data.timestamp = minute + ":00";

        for (size_t i = 0; i < rowsInMinute.size(); ++i) {
            const auto& row = rowsInMinute[i];
            int price = std::stoi(row[headerIndex.at("last_traded_price")]);
            int vol = std::stoi(row[headerIndex.at("volume_trade_for_the_day")]);

            if (i == 0) data.open_price = price;
            data.high_price = std::max(data.high_price, price);
            data.low_price = std::min(data.low_price, price);
            data.close_price = price;
            data.volume = vol;
        }

        candles.push_back(data);
    }

    auto candles3m = aggregateCandles(candles, 3);
    auto candles5m = aggregateCandles(candles, 5);

    std::ostringstream localOutput;

    for (size_t i = 0; i < candles.size(); ++i) {
        std::string p1 = detectPattern(candles[i]);
        std::string p3 = (i + 3 <= candles.size()) ? detectPattern(candles3m[i]) : "na";
        std::string p5 = (i + 5 <= candles.size()) ? detectPattern(candles5m[i]) : "na";

        localOutput << token << ","
                    << candles[i].timestamp << ","
                    << candles[i].open_price << ","
                    << candles[i].high_price << ","
                    << candles[i].low_price << ","
                    << candles[i].close_price << ","
                    << candles[i].volume << ","
                    << p1 << "," << p3 << "," << p5 << "\n";
    }

    std::lock_guard<std::mutex> lock(outputMutex);
    output << localOutput.str();
}

int main() {
    std::string folderPath = "/mnt/c/Streaming_data/_1_minute_data/2025-05-02/20250715";
    std::map<int, std::vector<std::vector<std::string>>> groupedData;
    std::unordered_map<std::string, int> headerIndex;
    bool headerParsed = false;

    for (const auto& entry : fs::directory_iterator(folderPath)) {
        if (!entry.is_regular_file()) continue;

        std::ifstream file(entry.path());
        if (!file.is_open()) {
            std::cerr << "Error opening file: " << entry.path() << "\n";
            continue;
        }

        std::string line;
        std::getline(file, line); // header

        if (!headerParsed) {
            std::istringstream headerStream(line);
            std::string col;
            int idx = 0;
            while (std::getline(headerStream, col, ',')) {
                headerIndex[col] = idx++;
            }

            std::vector<std::string> required = {
                "token", "exchange_timestamp", "last_traded_price", "volume_trade_for_the_day"
            };
            for (const auto& col : required) {
                if (headerIndex.find(col) == headerIndex.end()) {
                    std::cerr << "Missing required column: " << col << "\n";
                    return 1;
                }
            }

            headerParsed = true;
        }

        while (std::getline(file, line)) {
            std::vector<std::string> row;
            std::istringstream ss(line);
            std::string value;
            while (std::getline(ss, value, ',')) {
                row.push_back(value);
            }

            if (row.size() < headerIndex.size()) continue;

            int token = std::stoi(row[headerIndex["token"]]);
            groupedData[token].push_back(row);
        }

        file.close();
    }

    std::ofstream output("candlestick_patterns.csv");
    output << "token,timestamp,open,high,low,close,volume,pattern_1m,pattern_3m,pattern_5m\n";

    std::vector<std::thread> threads;
    std::mutex outputMutex;

    for (const auto& [token, rows] : groupedData) {
        threads.emplace_back(processToken, token, rows, std::cref(headerIndex), std::ref(outputMutex), std::ref(output));
    }

    for (auto& t : threads) {
        t.join();
    }

    std::cout << "Hammer and shooting star detection complete. Results saved to candlestick_patterns.csv\n";
    return 0;
}
