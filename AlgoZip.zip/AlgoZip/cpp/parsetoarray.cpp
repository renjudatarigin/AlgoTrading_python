#include <azure/storage/blobs.hpp>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>

int main() {
    // Azure Storage account credentials
    std::string connection_string = "DefaultEndpointsProtocol=https;AccountName=storageaccountdatarig;AccountKey=mlqWv0MzjNhM40m0Z26BOH556vg7n2oOEqdNm3BkxjtzBRwFGmSnYBZ+wm0kxY2mYOGe4FFjgSa3+AStN8sb/Q==;EndpointSuffix=core.windows.net";
    std::string container_name = "stockdata";
    std::string blob_name = "20250302_market_data.csv";

    try {
        // Initialize BlobServiceClient
        auto blob_client = Azure::Storage::Blobs::BlobClient::CreateFromConnectionString(
            connection_string, container_name, blob_name);

        // Download blob content
        auto blob_download_response = blob_client.Download();
        std::vector<uint8_t> downloaded_data = blob_download_response.Value.BodyStream->ReadToEnd();
        std::string blob_data(downloaded_data.begin(), downloaded_data.end());

        // Store data in a 2D vector (array equivalent)
        std::vector<std::vector<std::string>> data_array;
        std::stringstream csv_stream(blob_data);
        std::string line;

        while (std::getline(csv_stream, line)) {
            std::vector<std::string> row;
            std::stringstream row_stream(line);
            std::string field;
            while (std::getline(row_stream, field, ',')) { // Assume CSV is comma-separated
                row.push_back(field);
            }
            data_array.push_back(row);
        }

        // Print success message after storing data
        std::cout << "Successfully written the data into the array!" << std::endl;

        // Print the stored data (optional)
        // for (const auto& row : data_array) {
        //     for (const auto& field : row) {
        //         std::cout << field << "\t";
        //     }
        //     std::cout << std::endl;
        // }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
