#include <iostream>
#include <thread>
#include <chrono>
#include <fstream>
#include <mutex>
#include <vector>
#include <ctime>
#include <nlohmann/json.hpp>
#include <websocketpp/config/asio_client.hpp>
#include <websocketpp/client.hpp>

using namespace std;
using json = nlohmann::json;

// WebSocket client setup
typedef websocketpp::client<websocketpp::config::asio_client> client;
mutex data_mutex;
vector<json> received_data;

// Function to handle incoming WebSocket messages
void onDataReceived(const json& message) {
    lock_guard<mutex> lock(data_mutex);
    received_data.push_back(message);
}

// Function to run WebSocket client and reconnect if necessary
void runWebSocket() {
    client ws_client;
    ws_client.init_asio();
    ws_client.set_message_handler([](websocketpp::connection_hdl hdl, client::message_ptr msg) {
        json message = json::parse(msg->get_payload());
        onDataReceived(message);
    });

    while (true) {
        websocketpp::lib::error_code ec;
        client::connection_ptr con = ws_client.get_connection("wss://your_websocket_url", ec);

        if (ec) {
            cerr << "WebSocket Connection Error: " << ec.message() << endl;
            this_thread::sleep_for(chrono::seconds(5)); // Retry after 5 seconds
            continue;
        }

        ws_client.connect(con);

        try {
            ws_client.run(); // Blocking call, exits if connection drops
        } catch (const exception& e) {
            cerr << "WebSocket Error: " << e.what() << endl;
        }

        cout << "Reconnecting WebSocket..." << endl;
        this_thread::sleep_for(chrono::seconds(3)); // Short delay before reconnecting
    }
}

// Function to check if it's 3:30 PM
bool isTimeToStop() {
    time_t now = time(0);
    struct tm* localTime = localtime(&now);
    return (localTime->tm_hour == 15 && localTime->tm_min >= 30);
}

// Function to save data to a file and upload to Azure
void saveData() {
    lock_guard<mutex> lock(data_mutex);
    if (received_data.empty()) return;

    ofstream file("data.json", ios::app);
    if (!file) {
        cerr << "Error opening file for writing." << endl;
        return;
    }
    
    for (const auto& data : received_data) {
        file << data.dump() << endl;
    }
    file.close();

    // Call Azure upload function (to be implemented)
    cout << "Data saved and uploaded to Azure." << endl;
    received_data.clear();
}

// Function to schedule periodic saving until 3:30 PM
void scheduleSave() {
    while (!isTimeToStop()) {
        this_thread::sleep_for(chrono::minutes(5)); // Save every 5 minutes
        saveData();
    }
    cout << "Stopping data collection at 3:30 PM." << endl;
}

int main() {
    thread ws_thread(runWebSocket);
    thread scheduler(scheduleSave);

    ws_thread.join();
    scheduler.join();
    return 0;
}
