#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <map>
#include <unordered_map>
#include <algorithm>
#include <chrono>
#include <iomanip>

using namespace std;
using namespace chrono;

struct TradeData {
    string token;
    system_clock::time_point exchange_timestamp;
    double last_traded_price;
};

struct AggregatedData {
    string token;
    system_clock::time_point timestamp;
    double open;
    double close;
    double high;
    double low;
};

system_clock::time_point parseTimestamp(const string& timestamp) {
    tm tm = {};
    istringstream ss(timestamp);
    ss >> get_time(&tm, "%d-%m-%Y %H:%M");
    return system_clock::from_time_t(mktime(&tm));
}

vector<TradeData> readCSV(const string& filename) {
    vector<TradeData> data;
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open file!" << endl;
        return data;
    }
    
    string line, token, timestamp, price_str;
    getline(file, line); // Skip header
    while (getline(file, line)) {
        stringstream ss(line);
        getline(ss, token, ',');
        getline(ss, timestamp, ',');
        getline(ss, price_str, ',');
        
        try {
            double price = stod(price_str);
            data.push_back({token, parseTimestamp(timestamp), price});
        } catch (const exception& e) {
            cerr << "Error parsing line: " << line << endl;
        }
    }
    file.close();
    return data;
}

void writeCSV(const string& filename, const vector<AggregatedData>& aggregated_data) {
    ofstream file(filename);
    file << "Token,timestamp,open,close,high,low\n";
    for (const auto& entry : aggregated_data) {
        time_t time = system_clock::to_time_t(entry.timestamp);
        file << entry.token << "," << put_time(localtime(&time), "%Y-%m-%d %H:%M")
             << "," << entry.open << "," << entry.close
             << "," << entry.high << "," << entry.low << "\n";
    }
    file.close();
}

int main() {
    string input_file = "C:/Arya/ALGO/cpp/data.csv";
    string output_file = "C:/Arya/ALGO/cpp/outputcppgrouping.csv";
    
    vector<TradeData> df = readCSV(input_file);
    if (df.empty()) {
        cerr << "Error: No data found in CSV file!" << endl;
        return 1;
    }
    
    auto min_date = df[0].exchange_timestamp;
    system_clock::time_point start_time = min_date + hours(9) + minutes(15);
    system_clock::time_point end_time = min_date + hours(15) + minutes(30);
    
    vector<system_clock::time_point> intervals;
    for (auto t = start_time; t < end_time; t += minutes(1)) {
        intervals.push_back(t);
    }
    
    vector<AggregatedData> aggregated_data;
    unordered_map<string, vector<TradeData>> token_data;
    
    for (const auto& row : df) {
        token_data[row.token].push_back(row);
    }
    
    for (const auto& [token, token_df] : token_data) {
        for (size_t i = 0; i < intervals.size() - 1; ++i) {
            auto start_interval = intervals[i];
            auto end_interval = intervals[i + 1];
            
            vector<TradeData> filtered_df;
            for (const auto& row : token_df) {
                if (row.exchange_timestamp >= start_interval && row.exchange_timestamp < end_interval) {
                    filtered_df.push_back(row);
                }
            }
            
            if (!filtered_df.empty()) {
                double open_price = filtered_df.front().last_traded_price;
                double close_price = filtered_df.back().last_traded_price;
                double high_price = max_element(filtered_df.begin(), filtered_df.end(),
                    [](const TradeData& a, const TradeData& b) { return a.last_traded_price < b.last_traded_price; })->last_traded_price;
                double low_price = min_element(filtered_df.begin(), filtered_df.end(),
                    [](const TradeData& a, const TradeData& b) { return a.last_traded_price < b.last_traded_price; })->last_traded_price;
                
                aggregated_data.push_back({token, start_interval, open_price, close_price, high_price, low_price});
            }
        }
    }
    
    writeCSV(output_file, aggregated_data);
    return 0;
}
