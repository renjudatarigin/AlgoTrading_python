import time
import datetime
import csv
import threading
import numpy as np
import pandas as pd
from SmartApi.smartWebSocketV2 import SmartWebSocketV2
from SmartApi import SmartConnect
from pyotp import TOTP
from azure.storage.blob import BlobServiceClient
from io import StringIO
import os
import tempfile
from dotenv import load_dotenv
import pytz
load_dotenv()

# SmartAPI Setup
API_KEY = "4GznkDiG"
CLIENT_ID = "R103352"
PIN = 7020
TOTP_SECRET = "RV62S7GJBGHGWKRAYSQ6SRTPVM"

obj = SmartConnect(API_KEY)
data = obj.generateSession(CLIENT_ID, PIN, TOTP(TOTP_SECRET).now())
feed_token = obj.getfeedToken()

# Define token list for the stocks
token_list = [
    # {"exchangeType": 1, "tokens": ["11532"]},  # ULTRACEMCO
    # {"exchangeType": 1, "tokens": ["10604"]},  # BHARTIARTL
    # {"exchangeType": 1, "tokens": ["11536"]},  # TCS
    # {"exchangeType": 1, "tokens": ["11630"]},  # NTPC
    # {"exchangeType": 1, "tokens": ["11723"]},  # JSWSTEEL
    # {"exchangeType": 1, "tokens": ["10999"]},  # MARUTI
    # {"exchangeType": 1, "tokens": ["11483"]},  # LT
    # {"exchangeType": 1, "tokens": ["1232"]},  # GRASIM
    # {"exchangeType": 1, "tokens": ["1363"]},  # HINDALCO
    # {"exchangeType": 1, "tokens": ["1394"]},  # HINDUNILVR
    # {"exchangeType": 1, "tokens": ["1660"]},  # ITC
    # {"exchangeType": 1, "tokens": ["16669"]},  # BAJAJ-AUTO
    # {"exchangeType": 1, "tokens": ["157"]},  # APOLLOHOSP
    # {"exchangeType": 1, "tokens": ["20374"]},  # COALINDIA
    # {"exchangeType": 1, "tokens": ["1964"]},  # TRENT
    # {"exchangeType": 1, "tokens": ["1594"]},  # INFY
    # {"exchangeType": 1, "tokens": ["16675"]},  # BAJAJFINSV
    # {"exchangeType": 1, "tokens": ["21808"]},  # SBILIFE
    # {"exchangeType": 1, "tokens": ["2475"]},  # ONGC
    # {"exchangeType": 1, "tokens": ["1922"]},  # KOTAKBANK
    # {"exchangeType": 1, "tokens": ["1333"]},  # HDFCBANK
    # {"exchangeType": 1, "tokens": ["13538"]},  # TECHM
    # {"exchangeType": 1, "tokens": ["3499"]},  # TATASTEEL
    # {"exchangeType": 1, "tokens": ["15083"]},  # ADANIPORTS
    # {"exchangeType": 1, "tokens": ["467"]},  # HDFCLIFE
    # {"exchangeType": 1, "tokens": ["17963"]},  # NESTLEIND
    # {"exchangeType": 1, "tokens": ["3456"]},  # TATAMOTORS
    # {"exchangeType": 1, "tokens": ["910"]},  # EICHERMOT
    # {"exchangeType": 1, "tokens": ["2031"]},  # M&M
    # {"exchangeType": 1, "tokens": ["14977"]},  # POWERGRID
    # {"exchangeType": 1, "tokens": ["881"]},  # DRREDDY
    # {"exchangeType": 1, "tokens": ["5900"]},  # AXISBANK
    # {"exchangeType": 1, "tokens": ["1348"]},  # HEROMOTOCO
    # {"exchangeType": 1, "tokens": ["236"]},  # ASIANPAINT
    # {"exchangeType": 1, "tokens": ["317"]},  # BAJFINANCE
    # {"exchangeType": 1, "tokens": ["3351"]},  # SUNPHARMA
    # {"exchangeType": 1, "tokens": ["3432"]},  # TATACONSUM
    # {"exchangeType": 1, "tokens": ["25"]},  # ADANIENT
    # {"exchangeType": 1, "tokens": ["694"]},  # CIPLA
    # {"exchangeType": 1, "tokens": ["2885"]},  # RELIANCE
    # {"exchangeType": 1, "tokens": ["383"]},  # BEL
    # {"exchangeType": 1, "tokens": ["4963"]},  # ICICIBANK
    # {"exchangeType": 1, "tokens": ["526"]},  # BPCL
    # {"exchangeType": 1, "tokens": ["547"]},  # BRITANNIA
    # {"exchangeType": 1, "tokens": ["3787"]},  # WIPRO
    # {"exchangeType": 1, "tokens": ["4306"]},  # SHRIRAMFIN
    # {"exchangeType": 1, "tokens": ["5258"]},  # INDUSINDBK
    # {"exchangeType": 1, "tokens": ["7229"]},  # HCLTECH
    # {"exchangeType": 1, "tokens": ["3045"]},  # SBIN
    {"exchangeType": 1, "tokens": ["26009"]}  # TITAN
]

# Azure Storage Account Setup
AZURE_CONNECTION_STRING ="DefaultEndpointsProtocol=https;AccountName=storageaccountdatarig;AccountKey=mlqWv0MzjNhM40m0Z26BOH556vg7n2oOEqdNm3BkxjtzBRwFGmSnYBZ+wm0kxY2mYOGe4FFjgSa3+AStN8sb/Q==;EndpointSuffix=core.windows.net"  # Replace with your actual connection string
CONTAINER_NAME = "stockdata"
BLOB_FILENAME = datetime.datetime.now().strftime("%Y%m%d") + "_market_data.csv"

# WebSocket Initialization
sws = SmartWebSocketV2(data["data"]["jwtToken"], API_KEY, CLIENT_ID, feed_token)

# -----------------------------------------
# Data Storage
df_list = []
price_history = []
highs = []
lows = []
closes = []

# Indicator Parameters
BOLLINGER_WINDOW = 20
ATR_WINDOW = 14
EMA_SHORT_PERIOD = 12
EMA_LONG_PERIOD = 26
RSI_PERIOD = 14

# Global Variables for Indicators
upper_band, lower_band, atr_value = None, None, None
ema_short, ema_long, rsi_value = None, None, None

# Function: Exponential Moving Average (EMA)
def calculate_ema(prices, period):
    if len(prices) < period:
        return None
    return np.round(np.mean(prices[-period:]), 2)

# Function: RSI Calculation
def calculate_rsi(prices, period=14):
    if len(prices) < period + 1:
        return None
    deltas = np.diff(prices)
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    avg_gain = np.mean(gains[-period:])
    avg_loss = np.mean(losses[-period:])
    if avg_loss == 0:
        return 100
    rs = avg_gain / avg_loss
    return np.round(100 - (100 / (1 + rs)), 2)

# Function: Bollinger Bands Calculation
def calculate_bollinger_bands(prices, window=20):
    if len(prices) < window:
        return None, None
    sma = np.mean(prices[-window:])
    std = np.std(prices[-window:])
    return sma + (2 * std), sma - (2 * std)

# Function: ATR Calculation
def calculate_atr(highs, lows, closes, window=14):
    if len(highs) < window:
        return None
    tr_values = [
        max(highs[i] - lows[i], abs(highs[i] - closes[i-1]), abs(lows[i] - closes[i-1]))
        for i in range(1, len(highs))
    ]
    return np.mean(tr_values[-window:])

# Function: Process Indicators
def process_indicators():
    global upper_band, lower_band, atr_value, ema_short, ema_long, rsi_value
    
    if len(price_history) >= BOLLINGER_WINDOW:
        upper_band, lower_band = calculate_bollinger_bands(price_history)
    
    if len(highs) >= ATR_WINDOW:
        atr_value = calculate_atr(highs, lows, closes)
    
    ema_short = calculate_ema(closes, EMA_SHORT_PERIOD)
    ema_long = calculate_ema(closes, EMA_LONG_PERIOD)
    rsi_value = calculate_rsi(closes, RSI_PERIOD)
# -----------------------------------------------------------------

# Create Temp File in VM
tmp_file = tempfile.NamedTemporaryFile(delete=False, mode='w+', newline='', encoding='utf-8')
# tmp_file = tempfile.NamedTemporaryFile(delete=False, mode='w+', prefix="my_temp_", dir="/tmp", newline='', encoding='utf-8')
# WebSocket: Data Handling
def on_data(wsapp, message):
    global price_history, highs, lows, closes, df_list
    try:
        last_price = message['last_traded_price']
        high_price = message['high_price_of_the_day']
        low_price = message['low_price_of_the_day']
        
         # Append prices to historical lists
        price_history.append(last_price)
        highs.append(high_price)
        lows.append(low_price)
        closes.append(last_price)

         # Maintain the correct size of each list
        price_history = price_history[-BOLLINGER_WINDOW:]
        highs = highs[-ATR_WINDOW:]
        lows = lows[-ATR_WINDOW:]
        closes = closes[-EMA_LONG_PERIOD:]

         # Process indicators in a separate thread
        threading.Thread(target=process_indicators, daemon=True).start()

        ist_timezone = pytz.timezone("Asia/Kolkata")
        exchange_timestamp = datetime.datetime.now(datetime.UTC).astimezone(ist_timezone)

        message.update({
            "UPPER BAND": upper_band,
            "LOWER BAND": lower_band,
            "ATR": atr_value,
            "EMA SHORT": ema_short,
            "EMA LONG": ema_long,
            "RSI": rsi_value,
            "exchange_timestamp": exchange_timestamp.strftime('%Y-%m-%d %H:%M:%S')
        })
        print("Ticks:", message)
        
        # Append data to the list
        df_list.append(message)

        # Append data to temp file
        with open(tmp_file.name, 'a', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=message.keys())
            if f.tell() == 0:
                writer.writeheader()
            writer.writerow(message)
    
    except Exception as e:
        print(f"Data Processing Error: {e}")

# Function: Save Data to Azure Storage
def save_to_azure():
    try:
        with open(tmp_file.name, 'r', encoding='utf-8') as f:
            blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
            blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=BLOB_FILENAME)
            blob_client.upload_blob(f.read(), overwrite=True)
            print("Data successfully uploaded to Azure Storage.")
    except Exception as e:
        print(f"Azure Upload Error: {e}")

ist_timezone = pytz.timezone("Asia/Kolkata")
# Function: Scheduled Save at 3:30 PM
def schedule_save():
    while True:
        
        now_utc = datetime.datetime.now(datetime.timezone.utc)  # Get UTC time
        now_ist = now_utc.astimezone(ist_timezone)  # Convert to IST
        # now = datetime.datetime.now()   
        # if now.hour == 11 and now.minute ==45 :  # 3:30 PM
        if now_ist.hour == 13 and now_ist.minute == 35:  
            print("Market Closed! Saving data...")
            save_to_azure()
            break
        time.sleep(60)  # Check every minute

# WebSocket Callbacks
sws.on_open = lambda wsapp: sws.subscribe("stream_1", 3, token_list)
sws.on_data = on_data
sws.on_error = lambda wsapp, error: print(f"WebSocket Error: {error}")
sws.on_close = lambda wsapp, close_status_code, close_msg: print(f"WebSocket Closed: {close_status_code} - {close_msg}")

# Start WebSocket Connection & Scheduler
try:
    threading.Thread(target=schedule_save).start()  # Run scheduler in the background
    sws.connect()
except Exception as e:
    print(f"Initial Connection Failed: {e}")
