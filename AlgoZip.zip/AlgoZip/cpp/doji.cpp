#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <thread>
#include <chrono>
#include <ctime>

using namespace std;

// Function to check if a row is a Doji pattern
bool is_doji(double open, double close, double high, double low) {
    double body_length = abs(close - open);
    double total_range = high - low;
    return (total_range != 0) && ((body_length / total_range) < 0.1) && (open == close);
}

// Function to analyze candlestick data without Armadillo
void analyze_candlestick_data(const string &file_path, const string &output_file) {
    ifstream file(file_path);
    ofstream out_file(output_file);

    if (!file.is_open() || !out_file.is_open()) {
        cerr << "Error opening file!" << endl;
        return;
    }

    string line;
    vector<string> header;
    
    // Read the header line
    if (getline(file, line)) {
        out_file << line << ",doji" << endl; // Append "doji" column to header
    }

    // Read each row
    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;
        string cell;
        
        // Split line by commas
        while (getline(ss, cell, ',')) {
            row.push_back(cell);
        }
        
        if (row.size() < 5) continue; // Skip if row doesn't have enough columns
        
        // Extract OHLC values
        double open = stod(row[1]);  // Assuming 2nd column is 'open'
        double close = stod(row[2]); // Assuming 3rd column is 'close'
        double high = stod(row[3]);  // Assuming 4th column is 'high'
        double low = stod(row[4]);   // Assuming 5th column is 'low'

        bool doji = is_doji(open, close, high, low);

        // Write the row with the new 'doji' column
        out_file << line << "," << (doji ? "1" : "0") << endl;
    }

    file.close();
    out_file.close();
}

int main() {
    string file_path = "C:/Arya/ALGO/cpp/output.csv";
    string output_file = "C:/Arya/ALGO/cpp/outputofdojicpp.csv";

    while (true) {
        // Print the current timestamp
        time_t now = time(0);
        tm *ltm = localtime(&now);
        cout << "Time: " << 1900 + ltm->tm_year << "-"
             << 1 + ltm->tm_mon << "-"
             << ltm->tm_mday << " "
             << ltm->tm_hour << ":"
             << ltm->tm_min << endl;

        cout << "///////////////////////////////////////////////////////////////" << endl;
        cout << "Analyzing: Stock" << endl;
        analyze_candlestick_data(file_path, output_file);
        cout << "Analysis complete! Output saved to " << output_file << endl;

        // Wait for 30 seconds before next iteration
        this_thread::sleep_for(chrono::seconds(30));
    }

    return 0;
}
